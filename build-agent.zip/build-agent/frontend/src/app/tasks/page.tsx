"use client";

import { useState } from "react";
import { useAgentStore } from "@/store/agentStore";
import {
  Play,
  Pause,
  Square,
  Plus,
  Trash2,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  Brain,
  Settings,
} from "lucide-react";
import toast from "react-hot-toast";

interface Task {
  id: string;
  goal: string;
  status: "pending" | "running" | "paused" | "completed" | "failed";
  progress: number;
  llmProvider: string;
  createdAt: string;
  completedAt?: string;
}

export default function TasksPage() {
  const { runTask, pauseTask, resumeTask, stopTask } = useAgentStore();
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: "1",
      goal: "Open Chrome and navigate to Google",
      status: "completed",
      progress: 100,
      llmProvider: "openai",
      createdAt: "2024-01-15T10:00:00Z",
      completedAt: "2024-01-15T10:02:00Z",
    },
    {
      id: "2",
      goal: "Search for latest AI news and summarize findings",
      status: "running",
      progress: 65,
      llmProvider: "anthropic",
      createdAt: "2024-01-15T10:05:00Z",
    },
    {
      id: "3",
      goal: "Open VS Code and create a new project",
      status: "pending",
      progress: 0,
      llmProvider: "gemini",
      createdAt: "2024-01-15T10:10:00Z",
    },
  ]);
  const [newTask, setNewTask] = useState("");
  const [selectedProvider, setSelectedProvider] = useState("openai");
  const [showNewTask, setShowNewTask] = useState(false);

  const handleCreateTask = async () => {
    if (!newTask.trim()) {
      toast.error("Please enter a task goal");
      return;
    }

    const task: Task = {
      id: Date.now().toString(),
      goal: newTask,
      status: "pending",
      progress: 0,
      llmProvider: selectedProvider,
      createdAt: new Date().toISOString(),
    };

    setTasks([task, ...tasks]);
    setNewTask("");
    setShowNewTask(false);
    toast.success("Task created and queued");

    try {
      await runTask(newTask);
      setTasks((prev) =>
        prev.map((t) =>
          t.id === task.id ? { ...t, status: "completed", progress: 100 } : t
        )
      );
      toast.success("Task completed!");
    } catch (error) {
      setTasks((prev) =>
        prev.map((t) =>
          t.id === task.id ? { ...t, status: "failed" } : t
        )
      );
      toast.error("Task failed");
    }
  };

  const handleDeleteTask = (id: string) => {
    setTasks(tasks.filter((t) => t.id !== id));
    toast.success("Task deleted");
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "running":
        return <Loader2 className="w-5 h-5 text-yellow-400 animate-spin" />;
      case "completed":
        return <CheckCircle2 className="w-5 h-5 text-green-400" />;
      case "failed":
        return <XCircle className="w-5 h-5 text-red-400" />;
      case "paused":
        return <Pause className="w-5 h-5 text-orange-400" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      pending: "bg-gray-500/20 text-gray-400",
      running: "bg-yellow-500/20 text-yellow-400",
      paused: "bg-orange-500/20 text-orange-400",
      completed: "bg-green-500/20 text-green-400",
      failed: "bg-red-500/20 text-red-400",
    };
    return (
      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Tasks</h1>
          <p className="text-gray-400 mt-1">Manage and monitor agent tasks</p>
        </div>
        <button
          onClick={() => setShowNewTask(!showNewTask)}
          className="flex items-center gap-2 px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors"
        >
          <Plus className="w-4 h-4" />
          New Task
        </button>
      </div>

      {/* New Task Form */}
      {showNewTask && (
        <div className="bg-dark-card rounded-xl border border-dark-border p-6 animate-fade-in">
          <h3 className="text-lg font-semibold text-white mb-4">Create New Task</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Task Goal</label>
              <textarea
                value={newTask}
                onChange={(e) => setNewTask(e.target.value)}
                placeholder="Describe what you want the agent to do..."
                rows={3}
                className="w-full bg-dark-bg border border-dark-border rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-primary-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">LLM Provider</label>
              <div className="flex gap-3">
                {["openai", "anthropic", "gemini", "openrouter"].map((provider) => (
                  <button
                    key={provider}
                    onClick={() => setSelectedProvider(provider)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      selectedProvider === provider
                        ? "bg-primary-500/20 text-primary-400 border border-primary-500/50"
                        : "bg-dark-bg text-gray-400 border border-dark-border hover:border-gray-500"
                    }`}
                  >
                    {provider.charAt(0).toUpperCase() + provider.slice(1)}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={handleCreateTask}
                className="flex items-center gap-2 px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors"
              >
                <Play className="w-4 h-4" />
                Execute Task
              </button>
              <button
                onClick={() => setShowNewTask(false)}
                className="px-4 py-2 bg-dark-bg hover:bg-dark-border text-gray-300 rounded-lg transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tasks Table */}
      <div className="bg-dark-card rounded-xl border border-dark-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-dark-border">
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Status</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Task</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Provider</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Progress</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Created</th>
                <th className="text-right px-6 py-4 text-sm font-medium text-gray-400">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-border">
              {tasks.map((task) => (
                <tr key={task.id} className="hover:bg-dark-border/30 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(task.status)}
                      {getStatusBadge(task.status)}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm font-medium text-white">{task.goal}</p>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 rounded bg-dark-bg text-xs text-gray-400">
                      {task.llmProvider}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="w-full max-w-[120px]">
                      <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-primary-500 rounded-full transition-all"
                          style={{ width: `${task.progress}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-400 mt-1">{task.progress}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-400">
                    {new Date(task.createdAt).toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-end gap-2">
                      {task.status === "running" && (
                        <>
                          <button
                            onClick={pauseTask}
                            className="p-1.5 rounded-lg text-yellow-400 hover:bg-yellow-500/20 transition-colors"
                          >
                            <Pause className="w-4 h-4" />
                          </button>
                          <button
                            onClick={stopTask}
                            className="p-1.5 rounded-lg text-red-400 hover:bg-red-500/20 transition-colors"
                          >
                            <Square className="w-4 h-4" />
                          </button>
                        </>
                      )}
                      {task.status === "paused" && (
                        <button
                          onClick={resumeTask}
                          className="p-1.5 rounded-lg text-green-400 hover:bg-green-500/20 transition-colors"
                        >
                          <Play className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        onClick={() => handleDeleteTask(task.id)}
                        className="p-1.5 rounded-lg text-gray-400 hover:bg-red-500/20 hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {tasks.length === 0 && (
          <div className="p-12 text-center text-gray-500">
            <Brain className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p className="text-lg font-medium">No tasks yet</p>
            <p className="text-sm mt-1">Create a new task to get started</p>
          </div>
        )}
      </div>
    </div>
  );
}
