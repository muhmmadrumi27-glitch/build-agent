"use client";

import { useState } from "react";
import {
  Grid3X3,
  List,
  Download,
  Trash2,
  Search,
  Image,
  Calendar,
  Clock,
  Maximize2,
  X,
  Filter,
} from "lucide-react";
import toast from "react-hot-toast";

interface Screenshot {
  id: string;
  path: string;
  timestamp: string;
  sessionId: string;
  width: number;
  height: number;
  isKeyFrame: boolean;
  ocrText?: string;
}

const sampleScreenshots: Screenshot[] = [
  {
    id: "1",
    path: "/screenshots/shot_1.png",
    timestamp: "2024-01-15T10:00:00Z",
    sessionId: "sess-123",
    width: 1920,
    height: 1080,
    isKeyFrame: true,
    ocrText: "Google Search",
  },
  {
    id: "2",
    path: "/screenshots/shot_2.png",
    timestamp: "2024-01-15T10:01:00Z",
    sessionId: "sess-123",
    width: 1920,
    height: 1080,
    isKeyFrame: false,
  },
  {
    id: "3",
    path: "/screenshots/shot_3.png",
    timestamp: "2024-01-15T10:02:00Z",
    sessionId: "sess-123",
    width: 1920,
    height: 1080,
    isKeyFrame: true,
    ocrText: "Search Results",
  },
];

export default function GalleryPage() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedScreenshot, setSelectedScreenshot] = useState<Screenshot | null>(null);
  const [screenshots] = useState<Screenshot[]>(sampleScreenshots);
  const [filterKeyFrame, setFilterKeyFrame] = useState(false);

  const filteredScreenshots = screenshots.filter((s) => {
    const matchesSearch = !searchQuery || 
      s.ocrText?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.sessionId.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = !filterKeyFrame || s.isKeyFrame;
    return matchesSearch && matchesFilter;
  });

  const handleDelete = (id: string) => {
    toast.success("Screenshot deleted");
  };

  const handleDownload = (screenshot: Screenshot) => {
    toast.success("Download started");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Screenshot Gallery</h1>
          <p className="text-gray-400 mt-1">Browse and manage captured screenshots</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewMode("grid")}
            className={`p-2 rounded-lg transition-colors ${
              viewMode === "grid" ? "bg-primary-500/20 text-primary-400" : "text-gray-400 hover:bg-dark-border"
            }`}
          >
            <Grid3X3 className="w-5 h-5" />
          </button>
          <button
            onClick={() => setViewMode("list")}
            className={`p-2 rounded-lg transition-colors ${
              viewMode === "list" ? "bg-primary-500/20 text-primary-400" : "text-gray-400 hover:bg-dark-border"
            }`}
          >
            <List className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 bg-dark-card rounded-xl border border-dark-border p-4">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by text or session..."
            className="w-full bg-dark-bg border border-dark-border rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary-500"
          />
        </div>
        <button
          onClick={() => setFilterKeyFrame(!filterKeyFrame)}
          className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors ${
            filterKeyFrame ? "bg-primary-500/20 text-primary-400" : "text-gray-400 hover:bg-dark-border"
          }`}
        >
          <Filter className="w-4 h-4" />
          Key Frames Only
        </button>
      </div>

      {/* Gallery */}
      {viewMode === "grid" ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredScreenshots.map((screenshot) => (
            <div
              key={screenshot.id}
              className="bg-dark-card rounded-xl border border-dark-border overflow-hidden hover:border-gray-600 transition-colors group"
            >
              <div
                className="aspect-video bg-gray-800 relative cursor-pointer"
                onClick={() => setSelectedScreenshot(screenshot)}
              >
                <div className="absolute inset-0 flex items-center justify-center">
                  <Image className="w-8 h-8 text-gray-600" />
                </div>
                {screenshot.isKeyFrame && (
                  <span className="absolute top-2 left-2 px-2 py-1 rounded bg-primary-500/80 text-white text-xs font-medium">
                    Key Frame
                  </span>
                )}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDownload(screenshot);
                    }}
                    className="p-2 rounded-lg bg-white/20 text-white hover:bg-white/30 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(screenshot.id);
                    }}
                    className="p-2 rounded-lg bg-white/20 text-white hover:bg-red-500/80 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="p-3">
                <p className="text-sm text-gray-300 truncate">{screenshot.ocrText || "Screenshot"}</p>
                <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {new Date(screenshot.timestamp).toLocaleDateString()}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {new Date(screenshot.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-dark-card rounded-xl border border-dark-border overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-dark-border">
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Screenshot</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">OCR Text</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Session</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Timestamp</th>
                <th className="text-right px-6 py-4 text-sm font-medium text-gray-400">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-border">
              {filteredScreenshots.map((screenshot) => (
                <tr key={screenshot.id} className="hover:bg-dark-border/30 transition-colors">
                  <td className="px-6 py-4">
                    <div className="w-16 h-10 bg-gray-800 rounded flex items-center justify-center">
                      <Image className="w-4 h-4 text-gray-600" />
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-white">{screenshot.ocrText || "-"}</td>
                  <td className="px-6 py-4 text-sm text-gray-400">{screenshot.sessionId}</td>
                  <td className="px-6 py-4 text-sm text-gray-400">
                    {new Date(screenshot.timestamp).toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleDownload(screenshot)}
                        className="p-1.5 rounded-lg text-gray-400 hover:bg-dark-border transition-colors"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(screenshot.id)}
                        className="p-1.5 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/20 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Lightbox */}
      {selectedScreenshot && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-8"
          onClick={() => setSelectedScreenshot(null)}
        >
          <button
            className="absolute top-4 right-4 p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
            onClick={() => setSelectedScreenshot(null)}
          >
            <X className="w-6 h-6" />
          </button>
          <div className="max-w-5xl max-h-full" onClick={(e) => e.stopPropagation()}>
            <div className="bg-gray-800 rounded-lg aspect-video flex items-center justify-center" style={{ width: "800px", height: "450px" }}>
              <Image className="w-16 h-16 text-gray-600" />
            </div>
            <div className="mt-4 flex items-center justify-between text-white">
              <div>
                <p className="font-medium">{selectedScreenshot.ocrText || "Screenshot"}</p>
                <p className="text-sm text-gray-400">
                  {selectedScreenshot.width}x{selectedScreenshot.height} • {new Date(selectedScreenshot.timestamp).toLocaleString()}
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleDownload(selectedScreenshot)}
                  className="flex items-center gap-2 px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Download
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
