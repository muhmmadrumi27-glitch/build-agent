"use client";

import { useEffect, useState } from "react";
import { useAgentStore } from "@/store/agentStore";
import { StatusCard } from "@/components/StatusCard";
import { TaskQueue } from "@/components/TaskQueue";
import { ScreenPreview } from "@/components/ScreenPreview";
import { ActivityLog } from "@/components/ActivityLog";
import { StatsChart } from "@/components/StatsChart";
import {
  Play,
  Pause,
  Square,
  Monitor,
  Brain,
  Shield,
  Activity,
  Zap,
} from "lucide-react";

export default function Dashboard() {
  const { status, connect, disconnect } = useAgentStore();
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    connect();
    setIsConnected(true);
    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  const stats = [
    {
      title: "Agent Status",
      value: status?.status || "Idle",
      icon: Brain,
      color: status?.status === "executing" ? "text-yellow-400" : "text-green-400",
      bgColor: status?.status === "executing" ? "bg-yellow-400/10" : "bg-green-400/10",
    },
    {
      title: "Active Sessions",
      value: "1",
      icon: Monitor,
      color: "text-blue-400",
      bgColor: "bg-blue-400/10",
    },
    {
      title: "Total Actions",
      value: String(status?.total_actions || 0),
      icon: Zap,
      color: "text-purple-400",
      bgColor: "bg-purple-400/10",
    },
    {
      title: "Success Rate",
      value: "95%",
      icon: Activity,
      color: "text-emerald-400",
      bgColor: "bg-emerald-400/10",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Dashboard</h1>
          <p className="text-gray-400 mt-1">
            Monitor and control your autonomous agent
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-dark-card border border-dark-border">
            <div className={`w-2 h-2 rounded-full ${isConnected ? "bg-green-400 animate-pulse" : "bg-red-400"}`} />
            <span className="text-sm text-gray-300">
              {isConnected ? "Connected" : "Disconnected"}
            </span>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <StatusCard
            key={index}
            title={stat.title}
            value={stat.value}
            icon={stat.icon}
            color={stat.color}
            bgColor={stat.bgColor}
          />
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Screen Preview */}
        <div className="lg:col-span-2">
          <ScreenPreview />
        </div>

        {/* Task Queue & Activity */}
        <div className="space-y-6">
          <TaskQueue />
          <ActivityLog />
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <StatsChart />
        <div className="bg-dark-card rounded-xl border border-dark-border p-6">
          <h3 className="text-lg font-semibold text-white mb-4">System Resources</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">CPU Usage</span>
                <span className="text-white">45%</span>
              </div>
              <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full" style={{ width: "45%" }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">Memory</span>
                <span className="text-white">62%</span>
              </div>
              <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                <div className="h-full bg-purple-500 rounded-full" style={{ width: "62%" }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">Disk</span>
                <span className="text-white">28%</span>
              </div>
              <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: "28%" }} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
