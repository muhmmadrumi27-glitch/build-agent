"use client";

import { useState } from "react";
import { useAgentStore } from "@/store/agentStore";
import {
  Camera,
  Scan,
  Type,
  MousePointer,
  Crosshair,
  Grid3X3,
  Eye,
  EyeOff,
  Download,
  ZoomIn,
  ZoomOut,
  RefreshCw,
} from "lucide-react";
import toast from "react-hot-toast";

export default function ScreenPage() {
  const { takeScreenshot, analyzeScreen } = useAgentStore();
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<any>(null);
  const [showOverlay, setShowOverlay] = useState(true);
  const [zoom, setZoom] = useState(1);
  const [activeTool, setActiveTool] = useState<"none" | "ocr" | "click" | "select">("none");

  const handleScreenshot = async () => {
    try {
      takeScreenshot();
      toast.success("Screenshot captured");
    } catch (error) {
      toast.error("Failed to capture screenshot");
    }
  };

  const handleAnalyze = async () => {
    try {
      analyzeScreen();
      toast.success("Screen analysis complete");
    } catch (error) {
      toast.error("Analysis failed");
    }
  };

  const tools = [
    { id: "none", label: "View", icon: Eye },
    { id: "ocr", label: "OCR", icon: Type },
    { id: "click", label: "Click", icon: MousePointer },
    { id: "select", label: "Select", icon: Crosshair },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Screen Control</h1>
          <p className="text-gray-400 mt-1">View, analyze, and interact with the screen</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleScreenshot}
            className="flex items-center gap-2 px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors"
          >
            <Camera className="w-4 h-4" />
            Screenshot
          </button>
          <button
            onClick={handleAnalyze}
            className="flex items-center gap-2 px-4 py-2 bg-dark-card hover:bg-dark-border text-white border border-dark-border rounded-lg transition-colors"
          >
            <Scan className="w-4 h-4" />
            Analyze
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-4 bg-dark-card rounded-xl border border-dark-border p-3">
        <div className="flex items-center gap-1">
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <button
                key={tool.id}
                onClick={() => setActiveTool(tool.id as any)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  activeTool === tool.id
                    ? "bg-primary-500/20 text-primary-400"
                    : "text-gray-400 hover:bg-dark-border hover:text-white"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tool.label}
              </button>
            );
          })}
        </div>
        <div className="h-6 w-px bg-dark-border" />
        <div className="flex items-center gap-1">
          <button
            onClick={() => setShowOverlay(!showOverlay)}
            className={`p-2 rounded-lg transition-colors ${
              showOverlay ? "text-primary-400 bg-primary-500/20" : "text-gray-400 hover:bg-dark-border"
            }`}
          >
            {showOverlay ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setZoom(Math.min(zoom + 0.25, 3))}
            className="p-2 rounded-lg text-gray-400 hover:bg-dark-border transition-colors"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => setZoom(Math.max(zoom - 0.25, 0.5))}
            className="p-2 rounded-lg text-gray-400 hover:bg-dark-border transition-colors"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-sm text-gray-400 w-12 text-center">{Math.round(zoom * 100)}%</span>
        </div>
        <div className="h-6 w-px bg-dark-border" />
        <button className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-gray-400 hover:bg-dark-border transition-colors">
          <Download className="w-4 h-4" />
          Export
        </button>
      </div>

      {/* Screen Canvas */}
      <div className="bg-dark-card rounded-xl border border-dark-border overflow-hidden">
        <div className="relative bg-black" style={{ height: "600px" }}>
          {screenshot ? (
            <div className="relative w-full h-full overflow-auto">
              <img
                src={screenshot}
                alt="Screen"
                className="origin-top-left"
                style={{ transform: `scale(${zoom})`, transformOrigin: "top left" }}
              />

              {/* UI Overlay */}
              {showOverlay && analysis?.elements && (
                <div className="absolute inset-0 pointer-events-none">
                  {analysis.elements.map((element: any, index: number) => (
                    <div
                      key={index}
                      className="absolute border-2 border-primary-500/60 rounded hover:border-primary-400"
                      style={{
                        left: `${(element.x / 1920) * 100}%`,
                        top: `${(element.y / 1080) * 100}%`,
                        width: `${(element.width / 1920) * 100}%`,
                        height: `${(element.height / 1080) * 100}%`,
                      }}
                    >
                      <span className="absolute -top-5 left-0 px-1.5 py-0.5 bg-primary-500 text-white text-xs rounded whitespace-nowrap">
                        {element.element_type} ({Math.round(element.confidence * 100)}%)
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500">
              <div className="text-center">
                <Grid3X3 className="w-16 h-16 mx-auto mb-4 opacity-30" />
                <p className="text-lg font-medium">No screen preview</p>
                <p className="text-sm mt-1">Take a screenshot to begin</p>
                <button
                  onClick={handleScreenshot}
                  className="mt-4 px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors"
                >
                  Capture Screen
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Info Bar */}
        {analysis && (
          <div className="p-4 border-t border-dark-border">
            <div className="grid grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-gray-400">Elements</p>
                <p className="text-white font-medium">{analysis.elements?.length || 0}</p>
              </div>
              <div>
                <p className="text-gray-400">Text Regions</p>
                <p className="text-white font-medium">{analysis.text_regions?.length || 0}</p>
              </div>
              <div>
                <p className="text-gray-400">Interactive</p>
                <p className="text-white font-medium">{analysis.interactive_elements?.length || 0}</p>
              </div>
              <div>
                <p className="text-gray-400">Resolution</p>
                <p className="text-white font-medium">
                  {analysis.dimensions?.width}x{analysis.dimensions?.height}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
