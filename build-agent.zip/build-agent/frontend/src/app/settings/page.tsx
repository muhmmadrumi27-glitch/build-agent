"use client";

import { useState } from "react";
import {
  Save,
  Key,
  Shield,
  Brain,
  Eye,
  Bell,
  Database,
  RefreshCw,
  CheckCircle2,
} from "lucide-react";
import toast from "react-hot-toast";

interface SettingsState {
  llmProvider: string;
  llmModel: string;
  safeMode: boolean;
  requireApproval: boolean;
  maxRetries: number;
  screenshotInterval: number;
  autoSave: boolean;
  notifications: boolean;
  darkMode: boolean;
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<SettingsState>({
    llmProvider: "openai",
    llmModel: "gpt-4o",
    safeMode: true,
    requireApproval: false,
    maxRetries: 3,
    screenshotInterval: 1.0,
    autoSave: true,
    notifications: true,
    darkMode: true,
  });
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setIsSaving(false);
    toast.success("Settings saved successfully");
  };

  const llmProviders = [
    { value: "openai", label: "OpenAI", models: ["gpt-4o", "gpt-4", "gpt-3.5-turbo"] },
    { value: "anthropic", label: "Anthropic", models: ["claude-3-5-sonnet-20241022", "claude-3-opus"] },
    { value: "gemini", label: "Google Gemini", models: ["gemini-1.5-pro", "gemini-1.5-flash"] },
    { value: "openrouter", label: "OpenRouter", models: ["anthropic/claude-3.5-sonnet"] },
  ];

  const currentProvider = llmProviders.find((p) => p.value === settings.llmProvider);

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-3xl font-bold text-white">Settings</h1>
        <p className="text-gray-400 mt-1">Configure agent behavior and preferences</p>
      </div>

      {/* LLM Configuration */}
      <div className="bg-dark-card rounded-xl border border-dark-border p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-primary-500/20 rounded-lg">
            <Brain className="w-5 h-5 text-primary-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">LLM Configuration</h3>
            <p className="text-sm text-gray-400">Configure AI model providers and settings</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Provider</label>
            <select
              value={settings.llmProvider}
              onChange={(e) => setSettings({ ...settings, llmProvider: e.target.value, llmModel: "" })}
              className="w-full bg-dark-bg border border-dark-border rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-primary-500"
            >
              {llmProviders.map((provider) => (
                <option key={provider.value} value={provider.value}>
                  {provider.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Model</label>
            <select
              value={settings.llmModel}
              onChange={(e) => setSettings({ ...settings, llmModel: e.target.value })}
              className="w-full bg-dark-bg border border-dark-border rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-primary-500"
            >
              {currentProvider?.models.map((model) => (
                <option key={model} value={model}>
                  {model}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Security Settings */}
      <div className="bg-dark-card rounded-xl border border-dark-border p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-red-500/20 rounded-lg">
            <Shield className="w-5 h-5 text-red-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Security & Safety</h3>
            <p className="text-sm text-gray-400">Control agent behavior and safety measures</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-dark-bg rounded-lg">
            <div>
              <p className="text-sm font-medium text-white">Safe Mode</p>
              <p className="text-xs text-gray-400 mt-1">Restrict destructive actions and require approval</p>
            </div>
            <button
              onClick={() => setSettings({ ...settings, safeMode: !settings.safeMode })}
              className={`relative w-12 h-6 rounded-full transition-colors ${
                settings.safeMode ? "bg-primary-500" : "bg-gray-600"
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  settings.safeMode ? "translate-x-7" : "translate-x-1"
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-dark-bg rounded-lg">
            <div>
              <p className="text-sm font-medium text-white">Require Approval</p>
              <p className="text-xs text-gray-400 mt-1">Ask for user confirmation before executing actions</p>
            </div>
            <button
              onClick={() => setSettings({ ...settings, requireApproval: !settings.requireApproval })}
              className={`relative w-12 h-6 rounded-full transition-colors ${
                settings.requireApproval ? "bg-primary-500" : "bg-gray-600"
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  settings.requireApproval ? "translate-x-7" : "translate-x-1"
                }`}
              />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Max Retries</label>
              <input
                type="number"
                value={settings.maxRetries}
                onChange={(e) => setSettings({ ...settings, maxRetries: parseInt(e.target.value) })}
                min={0}
                max={10}
                className="w-full bg-dark-bg border border-dark-border rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-primary-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Screenshot Interval (seconds)</label>
              <input
                type="number"
                value={settings.screenshotInterval}
                onChange={(e) => setSettings({ ...settings, screenshotInterval: parseFloat(e.target.value) })}
                min={0.1}
                max={10}
                step={0.1}
                className="w-full bg-dark-bg border border-dark-border rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-primary-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* General Settings */}
      <div className="bg-dark-card rounded-xl border border-dark-border p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-purple-500/20 rounded-lg">
            <Eye className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">General</h3>
            <p className="text-sm text-gray-400">Application preferences and display options</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-dark-bg rounded-lg">
            <div>
              <p className="text-sm font-medium text-white">Auto-save Sessions</p>
              <p className="text-xs text-gray-400 mt-1">Automatically save session data and screenshots</p>
            </div>
            <button
              onClick={() => setSettings({ ...settings, autoSave: !settings.autoSave })}
              className={`relative w-12 h-6 rounded-full transition-colors ${
                settings.autoSave ? "bg-primary-500" : "bg-gray-600"
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  settings.autoSave ? "translate-x-7" : "translate-x-1"
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-dark-bg rounded-lg">
            <div>
              <p className="text-sm font-medium text-white">Notifications</p>
              <p className="text-xs text-gray-400 mt-1">Enable desktop and in-app notifications</p>
            </div>
            <button
              onClick={() => setSettings({ ...settings, notifications: !settings.notifications })}
              className={`relative w-12 h-6 rounded-full transition-colors ${
                settings.notifications ? "bg-primary-500" : "bg-gray-600"
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  settings.notifications ? "translate-x-7" : "translate-x-1"
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-dark-bg rounded-lg">
            <div>
              <p className="text-sm font-medium text-white">Dark Mode</p>
              <p className="text-xs text-gray-400 mt-1">Use dark theme for the dashboard</p>
            </div>
            <button
              onClick={() => setSettings({ ...settings, darkMode: !settings.darkMode })}
              className={`relative w-12 h-6 rounded-full transition-colors ${
                settings.darkMode ? "bg-primary-500" : "bg-gray-600"
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  settings.darkMode ? "translate-x-7" : "translate-x-1"
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* API Keys */}
      <div className="bg-dark-card rounded-xl border border-dark-border p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-yellow-500/20 rounded-lg">
            <Key className="w-5 h-5 text-yellow-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">API Keys</h3>
            <p className="text-sm text-gray-400">Manage LLM provider API keys</p>
          </div>
        </div>

        <div className="space-y-4">
          {llmProviders.map((provider) => (
            <div key={provider.value} className="p-4 bg-dark-bg rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium text-white">{provider.label} API Key</label>
                <span className="text-xs text-gray-500">Encrypted at rest</span>
              </div>
              <div className="flex gap-2">
                <input
                  type="password"
                  placeholder={`Enter ${provider.label} API key...`}
                  className="flex-1 bg-dark-card border border-dark-border rounded-lg px-4 py-2.5 text-white placeholder-gray-500 focus:outline-none focus:border-primary-500"
                />
                <button className="px-4 py-2 bg-dark-border hover:bg-gray-600 text-white rounded-lg transition-colors text-sm">
                  Verify
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="flex items-center gap-2 px-6 py-3 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors disabled:opacity-50"
        >
          {isSaving ? (
            <RefreshCw className="w-5 h-5 animate-spin" />
          ) : (
            <Save className="w-5 h-5" />
          )}
          {isSaving ? "Saving..." : "Save Settings"}
        </button>
      </div>
    </div>
  );
}
