"use client";

import { useState } from "react";
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  ShieldOff,
  AlertTriangle,
  CheckCircle2,
  Clock,
  FileText,
  Lock,
  Unlock,
  User,
  Search,
  Settings,
  Save,
} from "lucide-react";
import toast from "react-hot-toast";

interface SecurityEvent {
  id: string;
  type: "blocked" | "approved" | "warning" | "info";
  action: string;
  details: string;
  severity: "low" | "medium" | "high" | "critical";
  timestamp: string;
  userId?: string;
  sessionId?: string;
}

interface SecurityPolicy {
  id: string;
  name: string;
  description: string;
  rules: string[];
  isActive: boolean;
  priority: number;
}

const sampleEvents: SecurityEvent[] = [
  {
    id: "evt-001",
    type: "blocked",
    action: "file_access",
    details: "Attempted access to .ssh/id_rsa blocked",
    severity: "high",
    timestamp: "2024-01-15T10:05:00Z",
    userId: "user-001",
    sessionId: "sess-001",
  },
  {
    id: "evt-002",
    type: "approved",
    action: "browser_navigate",
    details: "Navigation to https://google.com approved",
    severity: "low",
    timestamp: "2024-01-15T10:02:00Z",
    sessionId: "sess-001",
  },
  {
    id: "evt-003",
    type: "warning",
    action: "mouse_click",
    details: "Click on sensitive UI element detected",
    severity: "medium",
    timestamp: "2024-01-15T09:58:00Z",
    sessionId: "sess-002",
  },
  {
    id: "evt-004",
    type: "blocked",
    action: "command_execution",
    details: "Dangerous pattern detected: rm -rf",
    severity: "critical",
    timestamp: "2024-01-15T09:45:00Z",
    userId: "user-002",
  },
];

const samplePolicies: SecurityPolicy[] = [
  {
    id: "pol-001",
    name: "Sensitive File Protection",
    description: "Block access to sensitive system files",
    rules: ["Block .ssh/*", "Block .env files", "Block credential files"],
    isActive: true,
    priority: 1,
  },
  {
    id: "pol-002",
    name: "URL Filtering",
    description: "Filter and validate URLs before navigation",
    rules: ["Block malware domains", "Block phishing sites", "Validate HTTPS"],
    isActive: true,
    priority: 2,
  },
  {
    id: "pol-003",
    name: "Command Validation",
    description: "Validate commands for dangerous patterns",
    rules: ["Block rm -rf", "Block format commands", "Block eval()"],
    isActive: true,
    priority: 1,
  },
  {
    id: "pol-004",
    name: "Approval Required",
    description: "Require approval for high-risk actions",
    rules: ["File downloads", "App installation", "System commands"],
    isActive: false,
    priority: 3,
  },
];

export default function SecurityPage() {
  const [events] = useState<SecurityEvent[]>(sampleEvents);
  const [policies, setPolicies] = useState<SecurityPolicy[]>(samplePolicies);
  const [activeTab, setActiveTab] = useState<"events" | "policies" | "settings">("events");
  const [searchQuery, setSearchQuery] = useState("");
  const [severityFilter, setSeverityFilter] = useState<string>("all");
  const [showApiKeys, setShowApiKeys] = useState(false);

  const filteredEvents = events.filter((e) => {
    const matchesSearch = !searchQuery ||
      e.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.details.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSeverity = severityFilter === "all" || e.severity === severityFilter;
    return matchesSearch && matchesSeverity;
  });

  const togglePolicy = (id: string) => {
    setPolicies(policies.map((p) =>
      p.id === id ? { ...p, isActive: !p.isActive } : p
    ));
    toast.success("Policy updated");
  };

  const getSeverityColor = (severity: string) => {
    const colors = {
      low: "bg-gray-500/20 text-gray-400",
      medium: "bg-yellow-500/20 text-yellow-400",
      high: "bg-orange-500/20 text-orange-400",
      critical: "bg-red-500/20 text-red-400",
    };
    return colors[severity as keyof typeof colors] || colors.low;
  };

  const getEventIcon = (type: string) => {
    switch (type) {
      case "blocked":
        return <ShieldOff className="w-5 h-5 text-red-400" />;
      case "approved":
        return <ShieldCheck className="w-5 h-5 text-green-400" />;
      case "warning":
        return <ShieldAlert className="w-5 h-5 text-yellow-400" />;
      default:
        return <Shield className="w-5 h-5 text-gray-400" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Security</h1>
          <p className="text-gray-400 mt-1">Monitor security events and manage policies</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-green-500/20 rounded-lg">
          <ShieldCheck className="w-5 h-5 text-green-400" />
          <span className="text-sm font-medium text-green-400">System Secure</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-dark-card rounded-xl border border-dark-border p-4">
          <div className="flex items-center gap-2 mb-2">
            <ShieldOff className="w-4 h-4 text-red-400" />
            <span className="text-sm text-gray-400">Blocked Actions</span>
          </div>
          <p className="text-2xl font-bold text-white">{events.filter((e) => e.type === "blocked").length}</p>
        </div>
        <div className="bg-dark-card rounded-xl border border-dark-border p-4">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
            <span className="text-sm text-gray-400">Warnings</span>
          </div>
          <p className="text-2xl font-bold text-white">{events.filter((e) => e.type === "warning").length}</p>
        </div>
        <div className="bg-dark-card rounded-xl border border-dark-border p-4">
          <div className="flex items-center gap-2 mb-2">
            <ShieldCheck className="w-4 h-4 text-green-400" />
            <span className="text-sm text-gray-400">Approved</span>
          </div>
          <p className="text-2xl font-bold text-white">{events.filter((e) => e.type === "approved").length}</p>
        </div>
        <div className="bg-dark-card rounded-xl border border-dark-border p-4">
          <div className="flex items-center gap-2 mb-2">
            <Lock className="w-4 h-4 text-primary-400" />
            <span className="text-sm text-gray-400">Active Policies</span>
          </div>
          <p className="text-2xl font-bold text-white">{policies.filter((p) => p.isActive).length}</p>
        </div>
      </div>

      <div className="flex items-center gap-1 bg-dark-card rounded-xl border border-dark-border p-1">
        {[
          { id: "events", label: "Security Events", icon: ShieldAlert },
          { id: "policies", label: "Policies", icon: Shield },
          { id: "settings", label: "Settings", icon: Settings },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? "bg-primary-500/20 text-primary-400"
                  : "text-gray-400 hover:bg-dark-border hover:text-white"
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {activeTab === "events" && (
        <div className="space-y-4">
          <div className="flex items-center gap-4 bg-dark-card rounded-xl border border-dark-border p-4">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search events..."
                className="w-full bg-dark-bg border border-dark-border rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary-500"
              />
            </div>
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="bg-dark-bg border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-primary-500"
            >
              <option value="all">All Severities</option>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="critical">Critical</option>
            </select>
          </div>

          <div className="space-y-2">
            {filteredEvents.map((event) => (
              <div
                key={event.id}
                className="flex items-start gap-4 p-4 bg-dark-card rounded-xl border border-dark-border hover:border-gray-600 transition-colors"
              >
                <div className="mt-1">{getEventIcon(event.type)}</div>
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium text-white">{event.action}</span>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getSeverityColor(event.severity)}`}>
                      {event.severity}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                      event.type === "blocked" ? "bg-red-500/20 text-red-400" :
                      event.type === "approved" ? "bg-green-500/20 text-green-400" :
                      "bg-yellow-500/20 text-yellow-400"
                    }`}>
                      {event.type}
                    </span>
                  </div>
                  <p className="text-sm text-gray-400 mt-1">{event.details}</p>
                  <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(event.timestamp).toLocaleString()}
                    </span>
                    {event.userId && (
                      <span className="flex items-center gap-1">
                        <User className="w-3 h-3" />
                        {event.userId}
                      </span>
                    )}
                    {event.sessionId && (
                      <span className="flex items-center gap-1">
                        <FileText className="w-3 h-3" />
                        {event.sessionId}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === "policies" && (
        <div className="space-y-4">
          {policies.map((policy) => (
            <div
              key={policy.id}
              className="bg-dark-card rounded-xl border border-dark-border p-5"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <h3 className="text-lg font-semibold text-white">{policy.name}</h3>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                      policy.isActive ? "bg-green-500/20 text-green-400" : "bg-gray-500/20 text-gray-400"
                    }`}>
                      {policy.isActive ? "Active" : "Inactive"}
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-dark-bg text-xs text-gray-400">
                      Priority: {policy.priority}
                    </span>
                  </div>
                  <p className="text-sm text-gray-400 mt-1">{policy.description}</p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {policy.rules.map((rule, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 rounded bg-dark-bg text-xs text-gray-400"
                      >
                        {rule}
                      </span>
                    ))}
                  </div>
                </div>
                <button
                  onClick={() => togglePolicy(policy.id)}
                  className={`p-2 rounded-lg transition-colors ${
                    policy.isActive
                      ? "text-green-400 hover:bg-green-500/20"
                      : "text-gray-400 hover:bg-dark-border"
                  }`}
                >
                  {policy.isActive ? <Lock className="w-5 h-5" /> : <Unlock className="w-5 h-5" />}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === "settings" && (
        <div className="space-y-6 max-w-2xl">
          <div className="bg-dark-card rounded-xl border border-dark-border p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Security Level</h3>
            <div className="space-y-3">
              {["low", "medium", "high", "critical"].map((level) => (
                <label
                  key={level}
                  className="flex items-center gap-3 p-3 bg-dark-bg rounded-lg cursor-pointer hover:bg-dark-border/50 transition-colors"
                >
                  <input
                    type="radio"
                    name="securityLevel"
                    value={level}
                    className="w-4 h-4 text-primary-500"
                  />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-white capitalize">{level}</p>
                    <p className="text-xs text-gray-400">
                      {level === "low" && "Basic monitoring, no restrictions"}
                      {level === "medium" && "Approval for file operations"}
                      {level === "high" && "Approval for all browser actions"}
                      {level === "critical" && "Approval required for all actions"}
                    </p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="bg-dark-card rounded-xl border border-dark-border p-6">
            <h3 className="text-lg font-semibold text-white mb-4">API Key Visibility</h3>
            <div className="flex items-center justify-between p-3 bg-dark-bg rounded-lg">
              <div>
                <p className="text-sm font-medium text-white">Show API Keys</p>
                <p className="text-xs text-gray-400">Display API keys in settings page</p>
              </div>
              <button
                onClick={() => setShowApiKeys(!showApiKeys)}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  showApiKeys ? "bg-primary-500" : "bg-gray-600"
                }`}
              >
                <span
                  className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                    showApiKeys ? "translate-x-7" : "translate-x-1"
                  }`}
                />
              </button>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              onClick={() => toast.success("Security settings saved")}
              className="flex items-center gap-2 px-6 py-3 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors"
            >
              <Save className="w-5 h-5" />
              Save Security Settings
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
