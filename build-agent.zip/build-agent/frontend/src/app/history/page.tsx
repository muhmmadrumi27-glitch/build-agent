"use client";

import { useState } from "react";
import {
  History,
  Search,
  Filter,
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  Pause,
  ChevronDown,
  ChevronUp,
  Monitor,
  Brain,
  Zap,
  BarChart3,
} from "lucide-react";

interface Session {
  id: string;
  name: string;
  goal: string;
  status: "completed" | "failed" | "paused" | "running";
  startedAt: string;
  endedAt?: string;
  duration: number;
  totalActions: number;
  successfulActions: number;
  failedActions: number;
  llmProvider: string;
  llmModel: string;
  steps: { action: string; status: string; duration: number }[];
}

const sampleSessions: Session[] = [
  {
    id: "sess-001",
    name: "Morning Dashboard Check",
    goal: "Open analytics dashboard and capture key metrics",
    status: "completed",
    startedAt: "2024-01-15T08:00:00Z",
    endedAt: "2024-01-15T08:05:23Z",
    duration: 323,
    totalActions: 12,
    successfulActions: 12,
    failedActions: 0,
    llmProvider: "openai",
    llmModel: "gpt-4o",
    steps: [
      { action: "screenshot", status: "success", duration: 500 },
      { action: "browser_open", status: "success", duration: 2000 },
      { action: "browser_navigate", status: "success", duration: 1500 },
      { action: "screenshot", status: "success", duration: 500 },
    ],
  },
  {
    id: "sess-002",
    name: "Social Media Update",
    goal: "Post updates to Twitter and LinkedIn",
    status: "failed",
    startedAt: "2024-01-15T09:30:00Z",
    endedAt: "2024-01-15T09:32:15Z",
    duration: 135,
    totalActions: 8,
    successfulActions: 5,
    failedActions: 3,
    llmProvider: "anthropic",
    llmModel: "claude-3-5-sonnet",
    steps: [
      { action: "browser_open", status: "success", duration: 2000 },
      { action: "browser_navigate", status: "success", duration: 1200 },
      { action: "browser_click", status: "failed", duration: 500 },
    ],
  },
  {
    id: "sess-003",
    name: "File Organization",
    goal: "Organize Downloads folder by file type",
    status: "completed",
    startedAt: "2024-01-15T11:00:00Z",
    endedAt: "2024-01-15T11:08:45Z",
    duration: 525,
    totalActions: 24,
    successfulActions: 24,
    failedActions: 0,
    llmProvider: "gemini",
    llmModel: "gemini-1.5-pro",
    steps: [
      { action: "open_app", status: "success", duration: 1500 },
      { action: "mouse_click", status: "success", duration: 300 },
      { action: "mouse_drag", status: "success", duration: 800 },
    ],
  },
];

export default function HistoryPage() {
  const [sessions] = useState<Session[]>(sampleSessions);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [expandedSession, setExpandedSession] = useState<string | null>(null);

  const filteredSessions = sessions.filter((s) => {
    const matchesSearch = !searchQuery ||
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.goal.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || s.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle2 className="w-5 h-5 text-green-400" />;
      case "failed":
        return <XCircle className="w-5 h-5 text-red-400" />;
      case "paused":
        return <Pause className="w-5 h-5 text-orange-400" />;
      case "running":
        return <Zap className="w-5 h-5 text-yellow-400 animate-pulse" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      completed: "bg-green-500/20 text-green-400",
      failed: "bg-red-500/20 text-red-400",
      paused: "bg-orange-500/20 text-orange-400",
      running: "bg-yellow-500/20 text-yellow-400",
    };
    return (
      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    );
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">History</h1>
          <p className="text-gray-400 mt-1">View past sessions and execution logs</p>
        </div>
        <div className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-gray-400" />
          <span className="text-sm text-gray-400">{sessions.length} sessions</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-dark-card rounded-xl border border-dark-border p-4">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle2 className="w-4 h-4 text-green-400" />
            <span className="text-sm text-gray-400">Completed</span>
          </div>
          <p className="text-2xl font-bold text-white">
            {sessions.filter((s) => s.status === "completed").length}
          </p>
        </div>
        <div className="bg-dark-card rounded-xl border border-dark-border p-4">
          <div className="flex items-center gap-2 mb-2">
            <XCircle className="w-4 h-4 text-red-400" />
            <span className="text-sm text-gray-400">Failed</span>
          </div>
          <p className="text-2xl font-bold text-white">
            {sessions.filter((s) => s.status === "failed").length}
          </p>
        </div>
        <div className="bg-dark-card rounded-xl border border-dark-border p-4">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4 text-yellow-400" />
            <span className="text-sm text-gray-400">Total Actions</span>
          </div>
          <p className="text-2xl font-bold text-white">
            {sessions.reduce((sum, s) => sum + s.totalActions, 0)}
          </p>
        </div>
        <div className="bg-dark-card rounded-xl border border-dark-border p-4">
          <div className="flex items-center gap-2 mb-2">
            <Brain className="w-4 h-4 text-primary-400" />
            <span className="text-sm text-gray-400">Success Rate</span>
          </div>
          <p className="text-2xl font-bold text-white">
            {Math.round(
              (sessions.reduce((sum, s) => sum + s.successfulActions, 0) /
                sessions.reduce((sum, s) => sum + s.totalActions, 0)) *
                100
            )}%
          </p>
        </div>
      </div>

      <div className="flex items-center gap-4 bg-dark-card rounded-xl border border-dark-border p-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search sessions..."
            className="w-full bg-dark-bg border border-dark-border rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary-500"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-gray-400" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-dark-bg border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-primary-500"
          >
            <option value="all">All Status</option>
            <option value="completed">Completed</option>
            <option value="failed">Failed</option>
            <option value="paused">Paused</option>
            <option value="running">Running</option>
          </select>
        </div>
      </div>

      <div className="space-y-3">
        {filteredSessions.map((session) => (
          <div
            key={session.id}
            className="bg-dark-card rounded-xl border border-dark-border overflow-hidden hover:border-gray-600 transition-colors"
          >
            <div
              className="p-5 cursor-pointer"
              onClick={() => setExpandedSession(expandedSession === session.id ? null : session.id)}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <div className="mt-1">{getStatusIcon(session.status)}</div>
                  <div>
                    <div className="flex items-center gap-3">
                      <h3 className="text-lg font-semibold text-white">{session.name}</h3>
                      {getStatusBadge(session.status)}
                    </div>
                    <p className="text-sm text-gray-400 mt-1">{session.goal}</p>
                    <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(session.startedAt).toLocaleDateString()}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatDuration(session.duration)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Monitor className="w-3 h-3" />
                        {session.totalActions} actions
                      </span>
                      <span className="px-2 py-0.5 rounded bg-dark-bg text-gray-400">
                        {session.llmProvider} / {session.llmModel}
                      </span>
                    </div>
                  </div>
                </div>
                <button className="p-1.5 rounded-lg text-gray-400 hover:bg-dark-border transition-colors">
                  {expandedSession === session.id ? (
                    <ChevronUp className="w-5 h-5" />
                  ) : (
                    <ChevronDown className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            {expandedSession === session.id && (
              <div className="px-5 pb-5 border-t border-dark-border animate-fade-in">
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-white mb-3">Action Timeline</h4>
                  <div className="space-y-2">
                    {session.steps.map((step, index) => (
                      <div
                        key={index}
                        className="flex items-center gap-3 p-3 bg-dark-bg rounded-lg"
                      >
                        <span className="text-xs text-gray-500 w-6">{index + 1}</span>
                        <div className={`w-2 h-2 rounded-full ${step.status === "success" ? "bg-green-400" : "bg-red-400"}`} />
                        <span className="text-sm text-white flex-1">{step.action}</span>
                        <span className="text-xs text-gray-500">{step.duration}ms</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-4">
                  <div className="p-3 bg-dark-bg rounded-lg text-center">
                    <p className="text-2xl font-bold text-green-400">{session.successfulActions}</p>
                    <p className="text-xs text-gray-400">Successful</p>
                  </div>
                  <div className="p-3 bg-dark-bg rounded-lg text-center">
                    <p className="text-2xl font-bold text-red-400">{session.failedActions}</p>
                    <p className="text-xs text-gray-400">Failed</p>
                  </div>
                  <div className="p-3 bg-dark-bg rounded-lg text-center">
                    <p className="text-2xl font-bold text-white">{session.totalActions}</p>
                    <p className="text-xs text-gray-400">Total</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
