"""Security module for BuildAgent."""
import hashlib
import hmac
import json
import re
import secrets
import uuid
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from cryptography.fernet import Fernet
from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from loguru import logger
from passlib.context import CryptContext

from config import settings

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT configuration
security_bearer = HTTPBearer(auto_error=False)

# Encryption
_fernet: Optional[Fernet] = None


def get_fernet() -> Fernet:
    """Get or create Fernet instance."""
    global _fernet
    if _fernet is None:
        key = settings.encryption_key.encode()
        key = hashlib.sha256(key).digest()[:32]
        import base64
        _fernet = Fernet(base64.urlsafe_b64encode(key))
    return _fernet


def hash_password(password: str) -> str:
    """Hash a password."""
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its hash."""
    return pwd_context.verify(plain_password, hashed_password)


def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT access token."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.access_token_expire_minutes)
    to_encode.update({"exp": expire, "iat": datetime.utcnow(), "jti": str(uuid.uuid4())})
    encoded_jwt = jwt.encode(to_encode, settings.secret_key, algorithm="HS256")
    return encoded_jwt


def decode_access_token(token: str) -> Optional[Dict[str, Any]]:
    """Decode and validate a JWT token."""
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=["HS256"])
        return payload
    except JWTError:
        return None


async def get_current_user(credentials: HTTPAuthorizationCredentials = Security(security_bearer)) -> Dict[str, Any]:
    """Get current user from JWT token."""
    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = credentials.credentials
    payload = decode_access_token(token)

    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user_id = payload.get("sub")
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
        )

    return payload


def encrypt_sensitive_data(data: str) -> str:
    """Encrypt sensitive data."""
    fernet = get_fernet()
    return fernet.encrypt(data.encode()).decode()


def decrypt_sensitive_data(encrypted_data: str) -> str:
    """Decrypt sensitive data."""
    fernet = get_fernet()
    return fernet.decrypt(encrypted_data.encode()).decode()


def mask_sensitive_data(data: str, visible_chars: int = 4) -> str:
    """Mask sensitive data showing only last N characters."""
    if len(data) <= visible_chars:
        return "*" * len(data)
    return "*" * (len(data) - visible_chars) + data[-visible_chars:]


def generate_secure_id() -> str:
    """Generate a cryptographically secure random ID."""
    return secrets.token_urlsafe(32)


def sanitize_input(text: str) -> str:
    """Sanitize user input to prevent injection attacks."""
    # Remove null bytes
    text = text.replace("\x00", "")
    # Remove control characters except newlines and tabs
    text = "".join(char for char in text if char == "\n" or char == "\t" or ord(char) >= 32)
    return text.strip()


class SecurityPolicy:
    """Security policy enforcement."""

    # Dangerous patterns
    DANGEROUS_PATTERNS = [
        r"rm\s+-rf",
        r"format\s+",
        r"del\s+/f",
        r"rd\s+/s",
        r"mkfs\.",
        r"dd\s+if=",
        r">\s*/dev/",
        r":(){ :|:& };:",
        r"eval\s*\(",
        r"exec\s*\(",
        r"system\s*\(",
        r"subprocess\.call",
        r"os\.system",
    ]

    # Sensitive file patterns
    SENSITIVE_FILES = [
        r"\.ssh/",
        r"\.aws/",
        r"\.env",
        r"id_rsa",
        r"id_ed25519",
        r"\.pgpass",
        r"\.netrc",
        r"credentials",
        r"password",
        r"secret",
    ]

    # Allowed domains for browser
    ALLOWED_DOMAINS: List[str] = []
    BLOCKED_DOMAINS: List[str] = [
        "malware",
        "phishing",
        "virus",
    ]

    @classmethod
    def validate_command(cls, command: str) -> Tuple[bool, Optional[str]]:
        """Validate a command for dangerous patterns."""
        command_lower = command.lower()

        for pattern in cls.DANGEROUS_PATTERNS:
            if re.search(pattern, command_lower, re.IGNORECASE):
                return False, f"Dangerous pattern detected: {pattern}"

        return True, None

    @classmethod
    def validate_file_access(cls, file_path: str) -> Tuple[bool, Optional[str]]:
        """Validate file access for sensitive files."""
        file_lower = file_path.lower()

        for pattern in cls.SENSITIVE_FILES:
            if re.search(pattern, file_lower, re.IGNORECASE):
                return False, f"Access to sensitive file blocked: {pattern}"

        return True, None

    @classmethod
    def validate_url(cls, url: str) -> Tuple[bool, Optional[str]]:
        """Validate URL for safety."""
        url_lower = url.lower()

        for domain in cls.BLOCKED_DOMAINS:
            if domain in url_lower:
                return False, f"Blocked domain detected: {domain}"

        if cls.ALLOWED_DOMAINS:
            allowed = any(allowed in url_lower for allowed in cls.ALLOWED_DOMAINS)
            if not allowed:
                return False, "URL not in allowed domains list"

        return True, None

    @classmethod
    def validate_action(cls, action_type: str, parameters: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """Validate an action for security compliance."""
        # Check if safe mode is enabled
        if settings.safe_mode:
            # In safe mode, require approval for destructive actions
            destructive_actions = [
                "close_app", "browser_download", "file_delete",
                "registry_edit", "system_command"
            ]
            if action_type in destructive_actions:
                return True, "Action requires approval in safe mode"

        # Validate file paths in parameters
        if "file_path" in parameters:
            valid, error = cls.validate_file_access(parameters["file_path"])
            if not valid:
                return False, error

        if "path" in parameters:
            valid, error = cls.validate_file_access(parameters["path"])
            if not valid:
                return False, error

        # Validate URLs
        if "url" in parameters:
            valid, error = cls.validate_url(parameters["url"])
            if not valid:
                return False, error

        return True, None


class AuditLogger:
    """Audit logging for security events."""

    @staticmethod
    def log_security_event(
        event_type: str,
        details: Dict[str, Any],
        severity: str = "low",
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> None:
        """Log a security event."""
        log_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": event_type,
            "severity": severity,
            "user_id": user_id,
            "session_id": session_id,
            "details": details,
        }

        if severity in ["high", "critical"]:
            logger.warning(f"SECURITY EVENT [{severity}]: {json.dumps(log_data)}")
        else:
            logger.info(f"SECURITY EVENT [{severity}]: {json.dumps(log_data)}")

    @staticmethod
    def log_action(
        action_type: str,
        parameters: Dict[str, Any],
        result: str,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> None:
        """Log an action execution."""
        # Mask sensitive data in parameters
        masked_params = {}
        for key, value in parameters.items():
            if any(sensitive in key.lower() for sensitive in ["password", "token", "key", "secret"]):
                masked_params[key] = mask_sensitive_data(str(value))
            else:
                masked_params[key] = value

        log_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "action_type": action_type,
            "parameters": masked_params,
            "result": result,
            "user_id": user_id,
            "session_id": session_id,
        }
        logger.info(f"ACTION: {json.dumps(log_data)}")


class PermissionManager:
    """Permission management for user actions."""

    PERMISSIONS = {
        "admin": [
            "user:create", "user:read", "user:update", "user:delete",
            "session:create", "session:read", "session:update", "session:delete",
            "task:create", "task:read", "task:update", "task:delete",
            "workflow:create", "workflow:read", "workflow:update", "workflow:delete",
            "settings:read", "settings:update",
            "security:read", "security:update",
            "audit:read",
        ],
        "user": [
            "session:create", "session:read", "session:update", "session:delete",
            "task:create", "task:read", "task:update", "task:delete",
            "workflow:create", "workflow:read", "workflow:update", "workflow:delete",
            "settings:read", "settings:update",
        ],
        "viewer": [
            "session:read",
            "task:read",
            "workflow:read",
        ],
    }

    @classmethod
    def has_permission(cls, role: str, permission: str) -> bool:
        """Check if a role has a specific permission."""
        role_perms = cls.PERMISSIONS.get(role, [])
        return permission in role_perms or "admin" in role_perms

    @classmethod
    def require_permission(cls, permission: str):
        """Decorator to require a permission."""
        def decorator(func):
            async def wrapper(*args, **kwargs):
                user = kwargs.get("current_user")
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Authentication required",
                    )

                role = user.get("role", "viewer")
                if not cls.has_permission(role, permission):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail=f"Permission denied: {permission}",
                    )

                return await func(*args, **kwargs)
            return wrapper
        return decorator
